package com.coordsafe.mqtt.publisher;

import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.MqttPersistenceException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author Yang Wei
 * @Date Dec 14, 2013
 */
public abstract class MqttPublisher {
	protected static MqttClient mqttClient;
		private Logger logger = LoggerFactory.getLogger(MqttPublisher.class);

	protected MqttPublisher (){}
	
	public MqttPublisher (String brokerUrl, String clientId){
		try {
			mqttClient = new MqttClient(brokerUrl, clientId, null);
			mqttClient.connect();
		} catch (MqttException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void publish(String topic, MqttMessage message){
		try {
			if (mqttClient.isConnected()){
				mqttClient.publish(topic, message);
			
				logger.info("publish message to: " + topic);
			}
			else {
				logger.info("mqttClient is not connected");
			}
		} catch (MqttPersistenceException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (MqttException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
