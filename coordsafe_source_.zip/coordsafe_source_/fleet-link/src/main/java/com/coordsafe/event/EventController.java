/**
 * 
 */
package com.coordsafe.event;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.coordsafe.event.entity.GenericEvent;
import com.coordsafe.event.service.EventService;
import com.coordsafe.vehicle.service.VehicleGroupService;
import com.coordsafe.vehicle.service.VehicleService;

@Controller
@RequestMapping("/event")
public class EventController {
	private static final Logger logger = Logger.getLogger(EventController.class);
	
	@Autowired
	private EventService eventService;
	
	@Autowired
	private VehicleService vehicleService;
	
	@Autowired
	private VehicleGroupService vehicleGroupService;
	
	@RequestMapping(value="/trip/{tripId}", method=RequestMethod.GET)
	@ResponseBody
	public List<GenericEvent> listByTrip (@PathVariable("tripId") long tripId){
		logger.info("find event by trip: " + tripId);
		return eventService.findEventbyTrip(tripId);
	}
}
