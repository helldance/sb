/**
 * TripController.java
 * May 31, 2013
 * Yang Wei
 */
package com.coordsafe.trip.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.coordsafe.locator.entity.Locator;
import com.coordsafe.locator.service.LocatorService;
import com.coordsafe.trip.entity.Trip;
import com.coordsafe.trip.entity.TripSummary;
import com.coordsafe.trip.service.TripService;
import com.coordsafe.vehicle.entity.Vehicle;
import com.coordsafe.vehicle.entity.VehicleGroup;
import com.coordsafe.vehicle.service.VehicleGroupService;
import com.coordsafe.vehicle.service.VehicleService;

/**
 * @author Yang Wei
 *
 */
@Controller
@RequestMapping("/trip")
public class TripController {
	private static final Logger logger = Logger.getLogger(TripController.class);
	private final SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
	private final SimpleDateFormat sdf2 = new SimpleDateFormat("dd-MM-yyyy");
	
	@Autowired
	private TripService tripService;
	
	@Autowired
	private LocatorService locatorService;
	
	@Autowired
	private VehicleService vehicleService;
	
	@Autowired
	private VehicleGroupService vehicleGroupService;
		
	@RequestMapping(value="/company/{companyId}/{timeRange}", method=RequestMethod.GET)
	public String listTrip (@PathVariable("companyId") long companyId, @PathVariable("timeRange") String timeRange, Model model){
		List<Locator> locators = locatorService.findLocatorByCompany(companyId);
		
		// Shamir's request to add demo account 09/1/2014
		if (companyId == 99){
			long [] lIds = new long [] {36, 53, 24, 54};
			
			for (Long l : lIds){
				locators.add(locatorService.findLocatorById(l));
			}
		}
		
		List<Trip> trips = new ArrayList<Trip>();
		List<Vehicle> vehicles = new ArrayList<Vehicle>();
		List<VehicleGroup> vehiclegroups = new ArrayList<VehicleGroup>();
		
		Date _dtStart = null, _dtEnd = null;
		
		if (timeRange != null && timeRange != ""){
			String [] timeslice = timeRange.split(",");
		
			String stm = timeslice[0];
			String etm = timeslice[1];
			
			try {
				_dtStart = sdf2.parse(stm);
				_dtEnd = sdf2.parse(etm);
				_dtEnd = new Date(_dtEnd.getTime() + 24*3600*1000);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else {//default will retrieve last 3 days
			Calendar c = Calendar.getInstance();
			c.set(c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DATE));
			_dtEnd = c.getTime();
			
			c.setTimeInMillis(c.getTimeInMillis() - 3 * 24 * 3600 * 1000);
			_dtStart = c.getTime();
		}		
			
		// for (Locator l : locators){
		// 	logger.info(l.getLabel());
		// 	List<Trip> singleTrips = tripService.findByTime(l.getId(), _dtStart, _dtEnd);
		// 	trips.addAll(singleTrips);
		// }
		
		vehicles = vehicleService.findVehiclesByCompany(String.valueOf(companyId));
		vehiclegroups = vehicleGroupService.findVehicleGroupsByCompany(String.valueOf(companyId));
		
		model.addAttribute("trips", trips);
		model.addAttribute("vehiclegroups", vehiclegroups);
		model.addAttribute("vehicles", vehicles);
		// also return time range
		model.addAttribute("startdate", _dtStart.getTime());
		model.addAttribute("enddate", _dtEnd.getTime());
	
		return "trip/search";
	}
	
	
	
	@RequestMapping(value="/edit/{tripId}", method=RequestMethod.GET)
	public String editTrip (@PathVariable("tripId") long tripId, Model model){	
		Trip trip = tripService.findById(tripId);
		model.addAttribute(trip);
		
		return "trip/edit";
	}
	
	@RequestMapping(value="/{tripId}", method=RequestMethod.GET)
	public @ResponseBody Trip getTrip (@PathVariable("tripId") long tripId){
		return tripService.findById(tripId);
	}
	
	@RequestMapping(value="/{tripId}", method=RequestMethod.POST)
	public @ResponseBody Trip updateTrip (@RequestParam(value = "fuel_manual") double fuel, 
			@RequestParam(value = "mileage_manual") double mileage, @PathVariable long tripId){
		Trip trip = tripService.findById(tripId);
		
		trip.setMileage_manual(mileage);
		trip.setFuel_manual(fuel);
		
		tripService.update(trip);
		
		return trip;
	}
	
	/*@RequestMapping(method = RequestMethod.POST, value="/{tripId}")
	public void editVehicle(@PathVariable("tripId") long tripId, Trip trip) {
		logger.info("Edit trip: " + tripId);

		tripService.update(trip);			
	}*/
	

	private TripSummary buildSummaryForTrips (List<Trip> trips){
		TripSummary sum_trip = new TripSummary();
		int mile = 0, dur = 0, cnt_speed = 0, cnt_brake = 0;
				
		for (Trip trip : trips){
			mile += trip.getMileage();
			dur += trip.getMovingTime();
			//if (trip.getTripStartTime() != 0 || trip.getTripEndTime() != 0)
				//dur += trip.getTripEndTime().getTime() - trip.getTripStartTime().getTime();
			cnt_speed += trip.getSpeeding();
			cnt_brake += trip.getJameBreak();
		}
		
		sum_trip.mileage = mile;
		sum_trip.tripCount = trips.size();
		sum_trip.duration = dur;
		sum_trip.brakeCount = cnt_brake;
		sum_trip.speedCount = cnt_speed;
		
		return sum_trip;		
	}
}
