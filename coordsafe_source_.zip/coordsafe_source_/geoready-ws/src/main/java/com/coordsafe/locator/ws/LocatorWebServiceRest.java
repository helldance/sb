package com.coordsafe.locator.ws;

import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Response;

@Path("/")
/*@CrossOriginResourceSharing(
        allowOrigins = "*", 
        allowCredentials = true, 
        exposeHeaders = { "X-custom-3", "X-custom-4" }
   )*/
public interface LocatorWebServiceRest {	
	/*@POST
	@Path("/auth")
	@Consumes(MediaType.APPLICATION_JSON)
	public Response login (Identity identity);*/
	
	@POST
	@Path("/login")
	public Response login(@HeaderParam("name") String name, @HeaderParam("password") String password);

	@Path("trip-detail/{tripId}")
	@GET
	public String findTripDetailById (@PathParam("tripId") String tripId);
}
