package com.coordsafe.locator.ws;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;
import javax.ws.rs.core.Response.Status;

//import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.coordsafe.core.rbac.entity.User;
import com.coordsafe.core.rbac.exception.UserException;
import com.coordsafe.core.rbac.service.UserService;
import com.coordsafe.event.service.EventService;
import com.coordsafe.locator.entity.LocatorLocationHistory;
import com.coordsafe.locator.service.LocatorService;
import com.coordsafe.locator.service.LocatorServiceImpl;
import com.coordsafe.trip.service.TripService;
import com.coordsafe.vehicle.service.VehicleGroupService;
import com.coordsafe.vehicle.service.VehicleService;
import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationConfig;

public class LocatorWebServiceRestImpl implements LocatorWebServiceRest{
	//private static Logger logger = Logger.getLogger(LocatorServiceImpl.class);
	private final SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");

	@Autowired 
	private LocatorService locatorService;
	@Autowired
	private UserService userService;
	@Autowired
	private TripService tripService;
	@Autowired
	private VehicleService vehicleSvrs;
	@Autowired
	private EventService eventSvrs;
	@Autowired
	private VehicleGroupService vgSvrs; 

	/*@Override
	@POST
	@Path("/auth")
	@Consumes(MediaType.APPLICATION_JSON)
	public Response login(Identity identity) {
		System.out.println(identity.getName() + identity.getPassword());
		
		ResponseBuilder builder = Response.status(Status.OK);
		builder.entity(false);
			
		try {
			if  (userService.login(identity.getName(), identity.getPassword()) != null){
				builder.entity(true);
			}
		} catch (UserException e) {
			e.printStackTrace();
		}
		
		return builder.build();		
	}*/

	@Override
	@POST
	@Path("/login")
	public Response login(@HeaderParam("name") String name,
			@HeaderParam("password") String password) {
		
		ResponseBuilder builder = Response.status(Status.OK);
		builder.entity(false);
			
		try {
			User user = userService.login(name, password);
			if  (user != null){
				//HashMap<String, String> map = new HashMap<String, String>();
				
				//map.put("name", user.getUsername());
				//map.put("company", user.getCompanyName());
				
				//TODO: returns api key to user
				
				builder.entity(user.getUsername() + "/" + user.getCompany().getName() + "/" + user.getApiKey().getKey());
			}
		} catch (UserException e) {
			e.printStackTrace();
		}
		
		return builder.build();	
	}

	@Override
	@Path("trip-detail/{tripId}")
	@GET
	public String findTripDetailById(@PathParam("tripId") String tripId) {
		// TODO Auto-generated method stub
		List<LocatorLocationHistory> history = locatorService.findLocationHistoryByTrip(Long.parseLong(tripId));
		
		//logger.info("find history size ///" + history.size());
		
		ObjectMapper mapper = new ObjectMapper();
		String jsonStr = "";
		
		SerializationConfig serializationConfig = mapper.getSerializationConfig();  
		
		// define mix-in annotations
		//serializationConfig.addMixInAnnotations(LocatorLocationHistory.class, SimpleLocationHistoryFilter.class);  
		
		try {
			jsonStr = mapper.writer().writeValueAsString(history);
		} catch (JsonGenerationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return jsonStr;
	}
}