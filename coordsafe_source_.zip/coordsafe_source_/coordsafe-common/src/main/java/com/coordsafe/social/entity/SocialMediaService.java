package com.coordsafe.social.entity;

public enum SocialMediaService {
	FACEBOOK,
    TWITTER,
    GOOGLE,
    LINKEDIN

}
