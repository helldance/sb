package com.coordsafe.notification.entity;

import org.hibernate.annotations.DynamicUpdate;

import com.coordsafe.vehicle.entity.Vehicle;

import jakarta.persistence.Entity;
import jakarta.persistence.OneToOne;


@Entity
@DynamicUpdate(value = true)
public class VehicleNotificationSetting extends AbstractNotificationSetting{
	

	private static final long serialVersionUID = 1L;
	
	@OneToOne
	private Vehicle vehicle;

	public Vehicle getVehicle() {
		return vehicle;
	}

	public void setVehicle(Vehicle vehicle) {
		this.vehicle = vehicle;
	}


}
