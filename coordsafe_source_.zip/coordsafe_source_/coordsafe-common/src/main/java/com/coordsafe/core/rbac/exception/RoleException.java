package com.coordsafe.core.rbac.exception;

@SuppressWarnings("serial")
public class RoleException extends Exception {

	public RoleException() {
		
	}
	
	public RoleException(String msg) {
		super(msg);
	}
}
