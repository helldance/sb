package com.coordsafe.ward.entity;

public interface Owner {
	public String getOwnerId();
}
