package com.coordsafe.core.rbac.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.coordsafe.core.rbac.dao.RoleDAO;
import com.coordsafe.core.rbac.entity.Role;
import com.coordsafe.core.rbac.entity.RoleList;
import com.coordsafe.core.rbac.exception.RoleException;
import com.coordsafe.core.rbac.service.RoleService;

@Transactional(propagation = Propagation.REQUIRED)
@Service("roleService")
public class RoleServiceImpl implements RoleService {

	private RoleDAO roleDAO;

	@Autowired
	public void setRoleDAO(RoleDAO roleDAO) {
		this.roleDAO = roleDAO;
	}

	@Override
	public void addRole(Role role) throws RoleException {

		roleDAO.save(role);
	}

	@Override
	public void updateRole(Role role) throws RoleException {
		roleDAO.merge(role);
	}

	@Override
	public void removeRole(Role role) throws RoleException {
		roleDAO.delete(role);
	}

	@Override
	public RoleList findAllRoles() {
		return roleDAO.findAllRoles();
	}

	@Override
	public Role findByRoleName(String name) {
		// TODO Auto-generated method stub
		throw new UnsupportedOperationException("Unimplemented method 'findByRoleName'");
	}

	@Override
	public void removeRole(String name) {
		// TODO Auto-generated method stub
		throw new UnsupportedOperationException("Unimplemented method 'removeRole'");
	}

}
