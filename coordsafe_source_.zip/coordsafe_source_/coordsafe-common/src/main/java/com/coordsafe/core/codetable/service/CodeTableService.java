package com.coordsafe.core.codetable.service;

import java.util.Date;
import java.util.List;

import com.coordsafe.core.codetable.entity.CodeTable;
import com.coordsafe.core.codetable.exception.CodeTableException;
import com.coordsafe.core.rbac.entity.Resource;

public interface CodeTableService {

	void save(CodeTable codeTable) throws CodeTableException;

	void delete(String type, String code) throws CodeTableException;

	void update(CodeTable codeTable) throws CodeTableException;

	List<CodeTable> findAll();

	CodeTable findById(Long id);

    Object findByType(String string);

    Resource findByTypeCode(String string, String type);
}
