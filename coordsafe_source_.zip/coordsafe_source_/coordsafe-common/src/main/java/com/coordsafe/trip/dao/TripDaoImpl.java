/**
 * TripDaoImpl.java
 * Mar 17, 2013
 * Yang Wei
 */
package com.coordsafe.trip.dao;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

//import org.apache.log4j.Logger;
import org.glassfish.ha.store.criteria.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.SessionFactory;
import org.hibernate.persister.collection.mutation.RowMutationOperations.Restrictions;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Repository;

import com.coordsafe.locator.entity.Locator;
import com.coordsafe.locator.service.LocatorService;
import com.coordsafe.trip.entity.Trip;
import com.coordsafe.vehicle.entity.Vehicle;
import com.coordsafe.vehicle.service.VehicleService;

/**
 * @author Yang Wei
 *
 */
@Repository
public class TripDaoImpl implements TripDao {
	//private static final Logger logger = Logger.getLogger(TripDaoImpl.class);
	
	@Autowired
	private SessionFactory sessionFactory;	

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
		
	@Autowired
	private VehicleService vehicleService;

	public void setVehicleService(VehicleService vehicleService) {
		this.vehicleService = vehicleService;
	}
	
	@Autowired
	private LocatorService locatorService;

	public void setVehicleService(LocatorService locatorService) {
		this.locatorService = locatorService;
	}
	
	@Override
	public Trip findById(long id) {
		//logger.info("find trip by id: " + id);
		return (Trip) sessionFactory.getCurrentSession().createQuery("from Trip t where t.id=?").setParameter(0, id).uniqueResult();
	}	

	@Override
	public void create(Trip trip) {
		//logger.info("created trip " + trip.getLocatorId());
		trip.setValid(true);
		sessionFactory.getCurrentSession().save(trip);
	}

	@Override
	public void update(Trip trip) {
		sessionFactory.getCurrentSession().saveOrUpdate(trip);
	}

	@Override
	public void delete(Trip trip) {
		sessionFactory.getCurrentSession().delete(trip);
	}

}
