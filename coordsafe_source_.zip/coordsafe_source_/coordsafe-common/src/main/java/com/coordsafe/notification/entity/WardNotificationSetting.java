package com.coordsafe.notification.entity;

import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.annotations.SelectBeforeUpdate;

import com.coordsafe.ward.entity.Ward;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import jakarta.persistence.Entity;
import jakarta.persistence.ManyToOne;


@Entity
@DynamicUpdate(value = true)
@SelectBeforeUpdate(value = true)
@JsonIgnoreProperties(value= {"ward", "create", "createBy", "description"})
public class WardNotificationSetting extends AbstractNotificationSetting{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@ManyToOne
	private Ward ward;

	public Ward getWard() {
		return ward;
	}

	public void setWard(Ward ward) {
		this.ward = ward;
	}
	

}
