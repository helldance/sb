package com.coordsafe.core.rbac.exception;

@SuppressWarnings("serial")
public class OrganizationException extends Exception {

	public OrganizationException(String errMsg) {
		super(errMsg);
	}

}
