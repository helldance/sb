/**
 * ExceptionMessage.java
 * Jun 3, 2013
 * Yang Wei
 */
package com.coordsafe.constants;

/**
 * @author Yang Wei
 *
 */
public final class ExceptionMessage {

}
