/**
 * TripDao.java
 * Mar 17, 2013
 * Yang Wei
 */
package com.coordsafe.trip.dao;

import com.coordsafe.trip.entity.Trip;

public interface TripDao {
	public Trip findById(long id);

	public void create (Trip trip);
	public void update (Trip trip);
	public void delete (Trip trip);
	
}
