package com.coordsafe.social.entity;

public enum Role {
	ROLE_USER,
	ROLE_ADMIN,
	ROLE_RETAILER,
	ROLE_USER_CORP,
}
