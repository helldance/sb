/**
 * TripServiceImpl.java
 * Mar 17, 2013
 * Yang Wei
 */
package com.coordsafe.trip.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.coordsafe.locator.entity.LocatorLocationHistory;
import com.coordsafe.locator.service.LocatorService;
import com.coordsafe.trip.dao.TripDao;
import com.coordsafe.trip.entity.Trip;
import com.coordsafe.trip.entity.TripDetail;

/**
 * @author Yang Wei
 *
 */
@Transactional(propagation = Propagation.REQUIRED)
@Service
public class TripServiceImpl implements TripService{
	private static Log log = LogFactory.getLog(TripServiceImpl.class);
	
	@Autowired
	private TripDao tripDao;

	/**
	 * @param tripDao the tripDao to set
	 */
	public void setTripDao(TripDao tripDao) {
		this.tripDao = tripDao;
	}
	
	@Autowired
	private LocatorService locatorService;

	/**
	 * @param locatorService the locatorService to set
	 */
	public void setLocatorService(LocatorService locatorService) {
		this.locatorService = locatorService;
	}

	@Override
	public Trip findById(long id) {
		return tripDao.findById(id);
	}
	
	@Override
	public void create(Trip trip) {
		tripDao.create(trip);		
	}

	@Override
	public void update(Trip trip) {
		tripDao.update(trip);
	}

	@Override
	public void delete(Trip trip) {
		tripDao.delete(trip);		
	}

	@Override
	public TripDetail findTripDetailById(long tripId) {
		Trip trip = tripDao.findById(tripId);
		TripDetail tripDetail = new TripDetail();

		tripDetail.trip = trip;
		List<LocatorLocationHistory> llhs = locatorService.findLocationHistoryByTrip(tripId);
		
		log.info("find trip history count: " + llhs.size());
		
		tripDetail.history = llhs;
		
		return tripDetail;
	}
}
