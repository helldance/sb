package com.coordsafe.core.rbac.dao;

import java.util.List;

import com.coordsafe.core.rbac.entity.Permission;

public interface PermissionDAO {

	void save(Permission permission);

	void update(Permission permission);

	void delete(Permission permission);

	Permission load(Long id);

	List<Permission> findAll();
}
