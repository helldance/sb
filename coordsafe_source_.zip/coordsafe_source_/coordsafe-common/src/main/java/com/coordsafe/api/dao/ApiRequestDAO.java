/**
 * 
 */
package com.coordsafe.api.dao;

import com.coordsafe.api.entity.ApiRequest;

/**
 * @author Yang Wei
 *
 */
public interface ApiRequestDAO {
	public void create (ApiRequest req);
	public void update (ApiRequest req);
	public void delete (ApiRequest req);
	public ApiRequest findById(long id);
}
