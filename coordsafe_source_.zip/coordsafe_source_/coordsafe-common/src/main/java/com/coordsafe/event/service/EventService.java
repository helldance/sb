/**
 * EventService.java
 * May 30, 2013
 * Yang Wei
 */
package com.coordsafe.event.service;

import java.util.Date;
import java.util.List;

import com.coordsafe.event.entity.GenericEvent;
import com.coordsafe.event.entity.VehicleEvent;

/**
 * @author Yang Wei
 *
 */
public interface EventService {
	public void create(GenericEvent event);
	public void update(GenericEvent event);
	public void delete(GenericEvent event);
	
	public List<GenericEvent> findEventbyTrip(long tripId);
}
