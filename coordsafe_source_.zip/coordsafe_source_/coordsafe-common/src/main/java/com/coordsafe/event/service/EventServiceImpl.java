/**
 * EventServiceImpl.java
 * May 30, 2013
 * Yang Wei
 */
package com.coordsafe.event.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.coordsafe.event.dao.EventDAO;
import com.coordsafe.event.entity.GenericEvent;

/**
 * @author Yang Wei
 *
 */
@Service
@Transactional(propagation = Propagation.REQUIRED)
public class EventServiceImpl implements EventService{

	@Autowired
	private EventDAO eventDao;
	
	/**
	 * @param eventDao the eventDao to set
	 */
	public void setEventDao(EventDAO eventDao) {
		this.eventDao = eventDao;
	}

	@Override
	public void create(GenericEvent event) {
		eventDao.create(event);
	}

	@Override
	public void update(GenericEvent event) {
		eventDao.update(event);
	}

	@Override
	public void delete(GenericEvent event) {
		eventDao.delete(event);
	}

	@Override
	public List<GenericEvent> findEventbyTrip(long tripId) {
		return eventDao.findEventbyTrip(tripId);
	}

}
