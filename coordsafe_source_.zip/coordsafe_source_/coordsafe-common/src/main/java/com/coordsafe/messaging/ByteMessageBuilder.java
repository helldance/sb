package com.coordsafe.messaging;

/**
 * @author Yang Wei
 * @Date Mar 15, 2014
 */
@Deprecated
public class ByteMessageBuilder {
	public static ByteMessage build (){
		return null;
	}
}
