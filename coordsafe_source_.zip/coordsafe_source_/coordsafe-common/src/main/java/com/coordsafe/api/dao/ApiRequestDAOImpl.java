/**
 * 
 */
package com.coordsafe.api.dao;

import java.util.Date;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.coordsafe.api.entity.ApiRequest;

/**
 * @author Yang Wei
 *
 */
@Repository
@Transactional
public class ApiRequestDAOImpl implements ApiRequestDAO {
	private static final Log log = LogFactory.getLog(ApiRequestDAOImpl.class);

	@Autowired
	private SessionFactory sessionFactory;
	
	@Override
	public void create(ApiRequest req) {
		sessionFactory.getCurrentSession().save(req);
	}

	@Override
	public void update(ApiRequest req) {
		sessionFactory.getCurrentSession().update(req);
	}

	@Override
	public void delete(ApiRequest req) {
		sessionFactory.getCurrentSession().delete(req);
	}

	@Override
	public ApiRequest findById(long id) {
		return (ApiRequest) sessionFactory.getCurrentSession().createQuery("from ApiRequest rq where rq.id = :rqid").setParameter("rqid", id).uniqueResult();
	}

}
