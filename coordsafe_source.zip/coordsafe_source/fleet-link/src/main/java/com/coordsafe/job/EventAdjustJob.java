/**
 * EventAdjustJob.java
 * May 29, 2013
 * Yang Wei
 */
package com.coordsafe.job;

import org.springframework.stereotype.Service;

/**
 * @author Yang Wei
 *
 */
@Service
public class EventAdjustJob {
	//TODO adjust event location - when GPS is not fixed.
	
}
