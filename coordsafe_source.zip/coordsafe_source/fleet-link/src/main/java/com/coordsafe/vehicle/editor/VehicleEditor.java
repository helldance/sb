package com.coordsafe.vehicle.editor;

public class VehicleEditor {

}
