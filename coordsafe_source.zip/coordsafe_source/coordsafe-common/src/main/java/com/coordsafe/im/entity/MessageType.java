/**
 * @author Yang Wei
 * @Date Nov 11, 2013
 */
package com.coordsafe.im.entity;

/**
 * @author Yang Wei
 *
 */
public enum MessageType {
	CHAT, BROADCAST
}
