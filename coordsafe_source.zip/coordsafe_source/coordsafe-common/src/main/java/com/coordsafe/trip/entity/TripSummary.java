/**
 * @author Yang Wei
 * @Date Aug 7, 2013
 */
package com.coordsafe.trip.entity;

/**
 * @author Yang Wei
 *
 */
public class TripSummary {
	public int tripCount;
	public long mileage;
	public long duration;
	public int brakeCount;
	public int speedCount;
}
