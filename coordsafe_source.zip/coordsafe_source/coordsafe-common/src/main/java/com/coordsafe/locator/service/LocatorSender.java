package com.coordsafe.locator.service;

import com.coordsafe.locator.entity.Locator;

public class LocatorSender {
/*    @Autowired
    private JmsTemplate jmsTemplate;
*/   
    public void sendOrder(final Locator locator){
        //jmsTemplate.send((MessageCreator) locator);
    }

}
