package com.coordsafe.core.rbac.exception;

@SuppressWarnings("serial")
public class PermissionException extends Exception {

}
