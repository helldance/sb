/**
 * @author Yang Wei
 * @Date Nov 13, 2013
 */
package com.coordsafe.im.service;

import com.coordsafe.im.entity.InstantMessage;

/**
 * @author Yang Wei
 *
 */
public interface ImService {
	public void create(InstantMessage message);
}
