package com.coordsafe.config;

import com.coordsafe.config.Password;

public interface PasswordRule extends Password{
}
