/**
 * SimpleLocatorHistoryFilter.java
 * Jun 5, 2013
 * Yang Wei
 */
package com.coordsafe.locator.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author Yang Wei
 *
 */
@JsonIgnoreProperties(value=
{	"accuracy", 
	"bearing", 
	"distance" 
}) 
public interface SimpleLocationHistoryFilter {

}
