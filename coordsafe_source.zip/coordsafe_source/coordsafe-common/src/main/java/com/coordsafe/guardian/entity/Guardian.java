package com.coordsafe.guardian.entity;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Transient;

import com.coordsafe.common.entity.LatLng;
import com.coordsafe.company.entity.Company;
import com.coordsafe.student.Student;

import jakarta.persistence.Column;
import jakarta.persistence.Embedded;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToOne;

@Entity
public class Guardian implements java.io.Serializable{

	private static final long serialVersionUID = -5527566248002296042L;

	@Id
	@Column(name = "ID")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;

	@Column(name = "LOGIN", unique=true)
	private String login;

	@Column(name = "PASSWD")
	private String passwd;
	
	@Column(name = "EMAIL")
	private String email;
	
	@Column(name = "PHONE")
	private String phone;

	@Column(name = "ROLE")
	private String role;
	
	@Column
	private int retryCount = 0;
	
	@Column
	private Date lastLoginDt;
	
	@Column(name = "LOCKED")
    private boolean accountNonLocked;
	@Column(name = "EXPIRED")
    private boolean accountNonExpired;
	@Column(name = "ENABLED")
    private boolean enabled;
	
	private String uuidpwd;
	
	@ManyToMany(fetch = FetchType.EAGER)
	private Set<Student> students;
	
	@Transient
	private String confirmPassword;
	//social column
    /*@Enumerated(EnumType.STRING)
    @Column(name = "socialrole", length = 20)
    private Role socialrole;

    @Enumerated(EnumType.STRING)
    @Column(name = "sign_in_provider", length = 20)
    private SocialMediaService signInProvider;*/
	
	@ManyToOne
	private Company company;
    
    private int zoneLimit = 0;
    
    @Embedded
    private LatLng location;
    
	/**
	 * 
	 */
	public Guardian() {
		super();
		// TODO Auto-generated constructor stub
		
		zoneLimit = retryCount = 0;
	}
	
	

	/**
	 * @param login
	 * @param email
	 * @param phone
	 */
	public Guardian(String login, String email, String phone) {
		super();
		
		this.login = login;
		this.email = email;
		this.phone = phone;
	}



	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}

	public String getPasswd() {
		return passwd;
	}

	public void setPasswd(String passwd) {
		this.passwd = passwd;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public boolean isAccountNonLocked() {
		return accountNonLocked;
	}

	public void setAccountNonLocked(boolean accountNonLocked) {
		this.accountNonLocked = accountNonLocked;
	}

	public boolean isAccountNonExpired() {
		return accountNonExpired;
	}

	public void setAccountNonExpired(boolean accountNonExpired) {
		this.accountNonExpired = accountNonExpired;
	}

	public boolean isEnabled() {
		return enabled;
	}

	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}

	public Set<Student> getStudents() {
		return students == null? new HashSet<Student>() : students;
	}

	public void setStudents(Set<Student> students) {
		this.students = students;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getConfirmPassword() {
		return confirmPassword;
	}

	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}

	public String getUuidpwd() {
		return uuidpwd;
	}

	public void setUuidpwd(String uuidpwd) {
		this.uuidpwd = uuidpwd;
	}

	/**
	 * @return the retryCount
	 */
	public int getRetryCount() {
		return retryCount;
	}

	/**
	 * @param retryCount the retryCount to set
	 */
	public void setRetryCount(int retryCount) {
		this.retryCount = retryCount;
	}

	/**
	 * @return the lastLoginDt
	 */
	public Date getLastLoginDt() {
		return lastLoginDt;
	}

	/**
	 * @param lastLoginDt the lastLoginDt to set
	 */
	public void setLastLoginDt(Date lastLoginDt) {
		this.lastLoginDt = lastLoginDt;
	}

	/**
	 * @return the zoneLimit
	 */
	public int getZoneLimit() {
		return zoneLimit;
	}

	/**
	 * @param zoneLimit the zoneLimit to set
	 */
	public void setZoneLimit(int zoneLimit) {
		this.zoneLimit = zoneLimit;
	}
	
	/**
	 * @return the company
	 */
	public Company getCompany() {
		return company;
	}

	/**
	 * @param company the company to set
	 */
	public void setCompany(Company company) {
		this.company = company;
	}



	/**
	 * @return the location
	 */
	public LatLng getLocation() {
		return location;
	}

	/**
	 * @param location the location to set
	 */
	public void setLocation(LatLng location) {
		this.location = location;
	}

}
