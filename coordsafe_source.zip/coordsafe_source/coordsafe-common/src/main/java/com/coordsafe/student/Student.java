package com.coordsafe.student;

public class Student {
    
}
