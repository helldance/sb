/**
 * TripDaoImpl.java
 * Mar 17, 2013
 * Yang Wei
 */
package com.coordsafe.trip.dao;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort.Order;
import org.springframework.stereotype.Repository;

import com.coordsafe.locator.entity.Locator;
import com.coordsafe.locator.service.LocatorService;
import com.coordsafe.trip.entity.Trip;
import com.coordsafe.vehicle.entity.Vehicle;
import com.coordsafe.vehicle.service.VehicleService;

import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;

/**
 * @author Yang Wei
 *
 */
@Repository
public class TripDaoImpl implements TripDao {
	private static final Logger logger = Logger.getLogger(TripDaoImpl.class);

	@Autowired
	private SessionFactory sessionFactory;

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Autowired
	private VehicleService vehicleService;

	public void setVehicleService(VehicleService vehicleService) {
		this.vehicleService = vehicleService;
	}

	@Autowired
	private LocatorService locatorService;

	public void setVehicleService(LocatorService locatorService) {
		this.locatorService = locatorService;
	}

	@Override
	public Trip findById(long id) {
		logger.info("find trip by id: " + id);
		return (Trip) sessionFactory.getCurrentSession().createQuery("from Trip t where t.id=?").setParameter(0, id)
				.uniqueResult();
	}

	@Override
	public Trip findCurrentOrLastTrip(long locatorId) {
		List<Trip> trips = (List<Trip>) sessionFactory.getCurrentSession()
				.createQuery("from Trip t where t.locatorId = ? order by id desc").setParameter(0, locatorId).list();

		if (trips != null && trips.size() > 0) {
			return trips.get(0);
		}

		return null;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Trip> findByTime(long locatorId, Date start, Date end) {
		logger.info("find trip by time: " + locatorId + " " + start.toString() + " " + end.toString());

		CriteriaBuilder criteriaBuilder = sessionFactory.getCurrentSession().getCriteriaBuilder();
		CriteriaQuery<Trip> criteriaQuery = criteriaBuilder.createQuery(Trip.class);
		Root<Trip> root = criteriaQuery.from(Trip.class);

		Predicate predicate = criteriaBuilder.and(
				criteriaBuilder.lessThanOrEqualTo(root.get("tripStartTime"), end),
				criteriaBuilder.greaterThanOrEqualTo(root.get("tripEndTime"), start),
				criteriaBuilder.equal(root.get("locatorId"), locatorId));

		criteriaQuery.where(predicate);
		criteriaQuery.orderBy(criteriaBuilder.asc(root.get("id")));

		return sessionFactory.getCurrentSession().createQuery(criteriaQuery).getResultList();

	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Trip> findByIDTime(long locatorId, String start, String end) {
		/*
		 * SQLQuery query = (SQLQuery) sessionFactory.getCurrentSession().
		 * createSQLQuery("SELECT * FROM TBL_TRIP T WHERE T.locator_Id=? and t.trip_Start_Time > to_timestamp(?,'YYYY-MM-DD HH24:MI') and t.trip_End_Time < to_timestamp(?,'YYYY-MM-DD HH24:MI')"
		 * )
		 * .setLong(0, locatorId)
		 * .setString(1,start)
		 * .setString(2, end);
		 * logger.debug("The SQL Query =" + query.getQueryString());
		 * return (List<Trip>) query.list();
		 */

		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm");

		try {
			Query<Trip> query = sessionFactory.getCurrentSession()
				   .createQuery("from Trip t where t.locatorId = :lid and t.tripStartTime > :stime and t.tripEndTime < :etime")
				   .setParameter("lid", locatorId)
				   .setParameter("stime", start)
				   .setParameter("etime", end);
			//logger.info("The SQL Query = {}", query.toString());
		
			return query.list();
		} catch (HibernateException e) {
			logger.error("Error executing query", e);
			throw new RuntimeException("Error executing query", e);
		}
	}

	@Override
	public void create(Trip trip) {
		logger.info("created trip " + trip.getLocatorId());
		trip.setValid(true);
		sessionFactory.getCurrentSession().save(trip);
	}

	@Override
	public void update(Trip trip) {
		sessionFactory.getCurrentSession().saveOrUpdate(trip);
	}

	@Override
	public void delete(Trip trip) {
		sessionFactory.getCurrentSession().delete(trip);
	}

	@Override
	public List<Trip> findUnprocessed() {
		Date threeDaysAgo = new Date(System.currentTimeMillis() - 3 * 24 * 3600 * 1000);

		return (List<Trip>) sessionFactory.getCurrentSession()
				.createQuery("from Trip t where t.mileage = 0 and t.tripEndId != 0 and t.tripEndTime > :endDt")
				.setParameter("endDt", threeDaysAgo).list();
	}

	@Override
	public List<Trip> findValid() {
		// TODO date subtract problem
		// return (List<Trip>) sessionFactory.getCurrentSession().createQuery("from Trip
		// t where t.mileage < ? and t.trip_end_time - t.trip_start_time < ?").list();
		return (List<Trip>) sessionFactory.getCurrentSession()
				.createQuery("from Trip t where t.valid = true and t.tripEndId != 0").list();
	}

	@Override
	public List<HashMap<String, List<Trip>>> findGroupTripByTime(long groupId, Date start, Date end) {
		List<HashMap<String, List<Trip>>> groupTripList = new ArrayList<>();
		List<Vehicle> vehicles = vehicleService.findVehicleByGroupId(groupId);

		// TODO: change locatorId to vehicle label.
		for (Vehicle v : vehicles) {
			Locator locator = v.getLocator();

			if (locator != null) {
				List<Trip> trips = this.findByTime(locator.getId(), start, end);

				HashMap<String, List<Trip>> map = new HashMap<>();
				map.put(v.getName() + " - " + v.getLicensePlate(), trips);

				groupTripList.add(map);
			}
		}

		return groupTripList;
	}

}
