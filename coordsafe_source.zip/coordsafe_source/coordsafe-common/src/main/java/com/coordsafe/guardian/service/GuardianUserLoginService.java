package com.coordsafe.guardian.service;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.coordsafe.guardian.entity.Guardian;
import com.coordsafe.guardian.security.GuardianUser;
import com.coordsafe.guardian.security.GuardianUserGrantedAuthority;

import jakarta.annotation.Resource;

@Service("guardianUserLoginService")
public class GuardianUserLoginService implements UserDetailsService
{
	private static final Log log = LogFactory.getLog(GuardianUserLoginService.class);
	
    @Resource(name="guardianService")
    private GuardianService guardianService;
    
    @Autowired
	private PasswordEncoder passwordEncoder;

    private Map<String,String> roles = new HashMap<String,String>();

    public GuardianUserLoginService()
    {
        roles.put("ROLE_USER","Customer");
        roles.put("ROLE_ADMIN","Admin");
    }

    public Map<String,String> getRoles()
    {
        return roles;
    }
    public String getPasswordEncoded(String passwd,GuardianUser guardian){
    	return passwordEncoder.encode(passwd);
    }
    public UserDetails loadUserByUsername(String username)
    {
        if (username != null && !username.equals(""))
        {
            //Guardian guardian = guardianService.get(username);
        	Guardian guardian = guardianService.getByNameOrEmail(username);
        	
        	log.info("retrieved guardian " + guardian);
        	
            if (guardian == null) {
                return null;
            }
                        
            GrantedAuthority grantedAuth = new GuardianUserGrantedAuthority(guardian.getRole());
            return new GuardianUser(guardian.getId(), 
            		guardian.getPasswd(),guardian.getLogin(),guardian.isAccountNonExpired(),
            		guardian.isAccountNonLocked(),guardian.isEnabled(), 
            		new GrantedAuthority[]{ grantedAuth });
        } else {
            return null;
        }
    }
}
