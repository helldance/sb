package com.coordsafe.common.entity;

public enum Gender {
	MALE, FEMALE
}
