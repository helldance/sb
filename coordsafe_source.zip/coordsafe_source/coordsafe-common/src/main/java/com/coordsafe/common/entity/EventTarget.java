/**
 * EventTarget.java
 * May 10, 2013
 * Yang Wei
 */
package com.coordsafe.common.entity;

import java.util.List;

/**
 * @author Yang Wei
 *
 */
public class EventTarget {
	public String userId;
	public int chanType;
	public List<String> chanList;
}
