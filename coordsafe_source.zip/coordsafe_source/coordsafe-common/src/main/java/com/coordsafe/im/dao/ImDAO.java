/**
 * @author Yang Wei
 * @Date Nov 13, 2013
 */
package com.coordsafe.im.dao;

import com.coordsafe.im.entity.InstantMessage;

/**
 * @author Yang Wei
 *
 */
public interface ImDAO {
	public void create(InstantMessage message);
}
