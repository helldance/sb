package com.coordsafe.config;

public interface Password {

	Boolean isPasswordValid(String password);
}
