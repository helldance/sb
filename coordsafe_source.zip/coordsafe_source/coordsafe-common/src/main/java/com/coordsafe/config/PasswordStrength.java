package com.coordsafe.config;

import com.coordsafe.config.Password;

public interface PasswordStrength extends Password {
}
